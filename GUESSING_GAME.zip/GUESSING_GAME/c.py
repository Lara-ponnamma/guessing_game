#THERES ONLY ONE CHANCE TO GUESS OVER HERE

from tkinter import *
import tkinter as tk
import random

from PIL import Image, ImageTk
from tkinter import PhotoImage

window = tk.Tk()
window.geometry("1000x1000")
window.title("@!")



image = Image.open("cal.jpg")
i1= ImageTk.PhotoImage(image)
label = Label(image=i1).place(x = 0,y = 0)

l1 = tk.Label(text="ENTER THE NUMBER YOU WANT TO GUESS", bg='white', fg='black')
l1.place(x=300, y=200)

t1 = tk.Entry()
t1.place(x=700, y=200)
t2 = tk.Entry(width = 40)
t2.place(x=400, y=300)

def clear():
    t1.delete(0, END)
    t2.delete(0, END)

def predict():
    guess = random.randint(1, 100)

    try:
        user_guess = int(t1.get())
        if user_guess < guess:
            t2.insert(0, "OOPSI GUESSED NUMBER IS LOW YOU LOST\n")
        elif user_guess > guess:
            t2.insert(0, "OOPSI GUESSED NUMBER IS HIGH YOU LOST\n")
        else:
            t2.insert(0, f"YOU WON! The number was {guess}\n")
    except ValueError:
        t2.insert(0, "Please enter a valid number\n")

b11 = tk.Button(text="CLEAR", fg="black", bg='white', command=clear)
b11.place(x=300, y=400)
b12 = tk.Button(text="PREDICT", fg="black", bg='white', command=predict)
b12.place(x=700, y=400)

window.mainloop()


